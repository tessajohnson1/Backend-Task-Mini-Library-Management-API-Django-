from django.contrib import admin
from django.urls import path
from library.views import *
from rest_framework_simplejwt.views import TokenObtainPairView

urlpatterns = [
    path('admin/', admin.site.urls),

    path('api/register/', register),
    path('api/login/', TokenObtainPairView.as_view()),
    path('api/books/', books_list),
    path('api/borrow/<int:book_id>/', borrow_book),
    path('api/return/<int:book_id>/', return_book),
    path('api/my-borrows/', my_borrows),
]
