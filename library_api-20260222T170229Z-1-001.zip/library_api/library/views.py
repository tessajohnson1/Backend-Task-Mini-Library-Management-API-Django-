from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from django.contrib.auth.models import User
from .models import Book, Borrow
from .serializers import RegisterSerializer, BookSerializer

@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = RegisterSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    return Response(serializer.data)


@api_view(['GET'])
def books_list(request):
    books = Book.objects.all()
    serializer = BookSerializer(books, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def borrow_book(request, book_id):
    book = Book.objects.get(id=book_id)
    if book.available_copies <= 0:
        return Response({"error": "No copies available"})
    book.available_copies -= 1
    book.save()
    Borrow.objects.create(user=request.user, book=book)
    return Response({"message": "Book borrowed"})


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def return_book(request, book_id):
    book = Book.objects.get(id=book_id)
    book.available_copies += 1
    book.save()
    return Response({"message": "Book returned"})


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def my_borrows(request):
    borrows = Borrow.objects.filter(user=request.user)
    return Response([
        {"book": b.book.title, "date": b.borrowed_at}
        for b in borrows
    ])
